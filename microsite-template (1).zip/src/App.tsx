import {
  Navbar,
  Hero,
  LogoCloud,
  Features,
  Stats,
  Testimonials,
  Pricing,
  FAQ,
  CTA,
  Team,
  Timeline,
  Footer,
  Divider,
} from './components';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <Navbar
        logoText="MicroSite"
        ctaText="Get Started"
        sticky={true}
      />

      {/* Hero Section */}
      <Hero
        badge="🚀 Launch your site in minutes"
        title="Build beautiful microsites faster than ever"
        subtitle="A comprehensive component library with everything you need to create stunning landing pages. Fully customizable, responsive, and ready to use."
        primaryCta="Start Building"
        secondaryCta="View Components"
        variant="centered"
        showPlayButton={true}
      />

      {/* Logo Cloud */}
      <LogoCloud
        title="Trusted by innovative teams"
        variant="simple"
        grayscale={true}
      />

      <Divider spacing="lg" />

      {/* Features - Cards variant */}
      <Features
        badge="Features"
        title="Everything you need to build"
        subtitle="Our component library includes all the sections you need to create professional landing pages and microsites."
        cols={3}
        gap="lg"
        variant="cards"
        cardHover={true}
      />

      {/* Stats */}
      <Stats
        title="Trusted by thousands"
        subtitle="Numbers that speak for themselves."
        variant="simple"
        cols={4}
      />

      {/* Testimonials */}
      <Testimonials
        title="Loved by developers"
        subtitle="See what our users have to say about their experience."
        cols={3}
        variant="cards"
        showRating={true}
      />

      {/* Timeline */}
      <Timeline
        title="Our Roadmap"
        subtitle="See what we've accomplished and what's coming next."
        variant="vertical"
        bgColor="bg-gray-50"
      />

      {/* Pricing */}
      <Pricing
        title="Simple, transparent pricing"
        subtitle="Choose the plan that works best for you."
        cols={3}
      />

      {/* FAQ */}
      <FAQ
        title="Frequently asked questions"
        subtitle="Find answers to common questions."
        variant="simple"
        iconStyle="chevron"
        bgColor="bg-gray-50"
      />

      {/* Team */}
      <Team
        title="Meet the team"
        subtitle="The people behind this project."
        cols={4}
        variant="cards"
        showSocial={true}
      />

      {/* CTA */}
      <CTA
        title="Ready to get started?"
        subtitle="Create your first microsite in minutes with our component library."
        primaryCta="Start Building"
        secondaryCta="Learn More"
        variant="gradient"
      />

      {/* Footer */}
      <Footer
        logoText="MicroSite"
        tagline="Build beautiful microsites faster than ever."
        variant="columns"
        showNewsletter={true}
      />
    </div>
  );
}

export default App;
